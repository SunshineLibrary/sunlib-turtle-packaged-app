function AppListCtrl($scope, $timeout, $http) {
	$scope.refreshApps = function () {
		$http.get('/apps?launchable=1').success(function (data, status, headers, config) {
			if (200 != status) {
				console.log("cannot connect to server");
				return;
			}
			console.log("apps:" + JSON.stringify(data));
			$scope.apps = data;
			for (var i = 0; i < $scope.apps.length; i++) {
				var app = $scope.apps[i];
				app.home_url = app.url + app.home;
			}
			$scope.lastSuccess = new Date().getTime();
		});
	}
	// refresh app list
	cancelRefresh = $timeout(function refreshApp() {
		console.log("refreshApp");
		$scope.refreshApps();
		cancelRefresh = $timeout(refreshApp, 30000);
	}, 0);
	cancelBootstrap = $timeout(function bootstrap() {
		console.log("bootstrap");
		if (typeof $scope.apps != "undefined") {
			for (var i = 0; i < $scope.apps.length; i++) {
				var app = $scope.apps[i];
				if (app.id == "0") {
					console.log("launcher found");
					$scope.currentSrc = "apps.html";
					$scope.currentApp = app;
					break;
				}
			}
		}
		if (typeof $scope.currentSrc === "undefined") {
			cancelBootstrap = $timeout(bootstrap, 1000);
		}
	}, 0);

	$scope.$on('$destroy', function (e) {
		$timeout.cancel(cancelRefresh);
		$timeout.cancel(cancelBootstrap);
	});

	$scope.totalApps = (typeof apps === "undefined") ? 0 : apps.length;
	$scope.changeApp = function (app) {
		console.log("changing app to " + app.home_url);
		$scope.currentSrc = app.home_url;
		$scope.currentApp = app;
	}
	$scope.isActive = function (app) {
		if ($scope.currentApp === app) {
			return "active";
		}
	}
}
